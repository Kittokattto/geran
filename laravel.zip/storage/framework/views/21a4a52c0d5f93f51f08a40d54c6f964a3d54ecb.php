<?php $__env->startSection('title'); ?>
Mengemaskini Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link" >
                    
                            <a href="<?php echo url('/failkes/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Nama Fail Kes</b> </a>
                            <a href="<?php echo url('/failkes/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah fail kes</b></a>
                            <a href="<?php echo url('/failkes/edit/'.$geran->geran_id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Mengemaskini fail kes</b></a>
                           
                        </nav>                    
                    </div>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content">
                                <form id="demo-form2" action="update/<?php echo e($geran->geran_id); ?>" method="post" 
                                enctype="multipart/form-data" data-parsley-validate 
                                         class="form-horizontal form-label-left input_mask customerAddForm">
                                         <?php echo csrf_field(); ?>
                                <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Geran</h6>
                                        </div>
                                        <div class="card-body">

                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('tajuk') ? ' has-error' : ''); ?>">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="last-name"><?php echo e(trans('Jenis Geran')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <select name="tajuk" id="tajuk" onchange="myFunction()" class="form-control <?php if ($errors->has('tajuk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tajuk'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" aria-placeholder="<?php echo e($geran->tajuk_geran); ?>" required autocomplete="tajuk" autofocus>
                                                            <option value="" disabled selected hidden>Pilih Jenis Geran</option>
                                                            <option value="Geran"<?php if($geran->tajuk_geran == 'Geran'){ echo "selected"; }?>>Geran</option>
                                                            <option value="Geran Mukim"<?php if($geran->tajuk_geran == 'Geran Mukim'){ echo "selected"; }?>>Geran Mukim</option>
                                                            <option value="Pajakan"<?php if($geran->tajuk_geran == 'Pajakan'){ echo "selected"; }?>>Pajakan</option>
                                                            <option value="Pajakan Mukim"<?php if($geran->tajuk_geran == 'Pajakan Mukim'){ echo "selected"; }?>>Pajakan Mukim</option>
                                                            <option value="Hakmilik Sementara Daerah"<?php if($geran->tajuk_geran == 'Hakmilik Sementara Daerah'){ echo "selected"; }?>>Hakmilik Sementara Daerah</option>
                                                            <option value="Hakmilik Sementara Mukim"<?php if($geran->tajuk_geran == 'Hakmilik Sementara Mukim'){ echo "selected"; }?>>Hakmilik Sementara Mukim</option>
            
                                                          </select>
                                                        <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>
               
                                               
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_hakmilik') ? ' has-error' : ''); ?>">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('No. Hakmilik')); ?> <label class="text-danger">*</label> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                      <input type="text" id="no_hakmilik" name="no_hakmilik"  class="form-control validate[required]"  
                                                      value="<?php echo e($geran->no_hakmilik); ?>" placeholder="<?php echo e($geran->no_hakmilik); ?>" maxlength="25"  required  />
                                                      <?php if($errors->has('no_hakmilik')): ?>
                                                       <span class="help-block">
                                                           <strong><?php echo e($errors->first('no_hakmilik')); ?></strong>
                                                       </span>
                                                     <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>    
            
                                            <div class="row">
                                             
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Cukai Tahunan')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <label class="control-label ">RM :  </label><label class="control-label"><input type="text"  name="cukai" placeholder="<?php echo e($geran->cukai); ?>" value="<?php echo e($geran->cukai); ?>" class="form-control"></label>
                                                        <?php if($errors->has('cukai')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('cukai')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            
                                            </div>

                                            
                                            <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                <label class="control-label col-md-4 col-sm-4 col-xs-12"> <?php echo e(trans('Rizab Melayu')); ?></label>
                                                <div class="col-md-8 col-sm-8 col-xs-12 gender">
                                                    <input type="checkbox" <?php if($geran->rizab == '1'){ echo "checked"; }?> name="rizab" value="1" ><?php echo e(trans('')); ?>

                                                </div>
                                            </div>
                                        
                                


                                </div>
                                </div>

                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Maklumat Geran</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                             
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('negeri') ? ' has-error' : ''); ?>">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Negeri')); ?> <label class="text-danger">*</label> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <select name="negeri" id="negeri" class="form-control <?php if ($errors->has('negeri')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('negeri'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" aria-placeholder="<?php echo e($geran->negeri); ?>" required autocomplete="negeri" autofocus>
                                                            <option value="" disabled selected hidden>Pilih Negeri</option>
                                                            <option value="Johor"<?php if($geran->negeri == 'Johor'){ echo "selected"; }?>>Johor</option>
                                                            <option value="Kedah"<?php if($geran->negeri == 'Kedah'){ echo "selected"; }?>>Kedah</option>
                                                            <option value="Kelantan"<?php if($geran->negeri == 'Kelantan'){ echo "selected"; }?>>Kelantan</option>
                                                            <option value="Negeri Sembilan"<?php if($geran->negeri == 'Negeri Sembilan'){ echo "selected"; }?>>Negeri Sembilan</option>
                                                            <option value="Pahang"<?php if($geran->negeri == 'Pahang'){ echo "selected"; }?>>Pahang</option>
                                                            <option value="Perak"<?php if($geran->negeri == 'Perak'){ echo "selected"; }?>>Perak</option>
                                                            <option value="Perlis"<?php if($geran->negeri == 'Perlis'){ echo "selected"; }?>>Perlis</option>
                                                            <option value="Selangor"<?php if($geran->negeri == 'Selangor'){ echo "selected"; }?>>Selangor</option>
                                                            <option value="Terengganu"<?php if($geran->negeri == 'Terengganu'){ echo "selected"; }?>>Terengganu</option>
                                                            <option value="Kuala Lumpur"<?php if($geran->negeri == 'Kuala Lumpur'){ echo "selected"; }?>>Kuala Lumpur</option>
                                                            <option value="Melaka"<?php if($geran->negeri == 'Melaka'){ echo "selected"; }?>>Melaka</option>
                                                            <option value="Pulau Pinang"<?php if($geran->negeri == 'Pulau Pinang'){ echo "selected"; }?>>Pulau Pinang</option>
                                                            <option value="Sabah"<?php if($geran->negeri == 'Sabah'){ echo "selected"; }?>>Sabah</option>
                                                            <option value="Sarawak"<?php if($geran->negeri == 'Sarawak'){ echo "selected"; }?>>Sarawak</option>
                                                          </select>
                                                        <?php if ($errors->has('negeri')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('negeri'); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>
              
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('daerah') ? ' has-error' : ''); ?>">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Daerah')); ?> <label class="text-danger">*</label> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                      <input type="text" id="daerah" name="daerah"  class="form-control validate[required]"  value="<?php echo e($geran->daerah); ?>" placeholder="<?php echo e($geran->daerah); ?>" maxlength="25"  required  />
                                                      <?php if($errors->has('daerah')): ?>
                                                       <span class="help-block">
                                                           <strong><?php echo e($errors->first('daerah')); ?></strong>
                                                       </span>
                                                     <?php endif; ?>
                                                    </div>
                                                </div>
            
                                            </div>
                                            <div class="row">
                                             
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('lot') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No.Lot')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text"  name="lot" placeholder="<?php echo e($geran->no_lot); ?>" value="<?php echo e($geran->no_lot); ?>" class="form-control" maxlength="25" required>
                                                        <?php if($errors->has('lot')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('lot')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('tempat') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tempat Geran')); ?></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <?php if(!empty($geran->tempat)): ?>
                                                        <input type="text"  name="tempat" placeholder="<?php echo e($geran->tempat); ?>" value="<?php echo e($geran->tempat); ?>" class="form-control" maxlength="150" >
                                                        <?php else: ?>
                                                        <input type="text"  name="tempat" placeholder="<?php echo e(trans('Alamat Geran')); ?>" value="<?php echo e(old('tempat')); ?>" class="form-control" maxlength="100" >
                                                        <?php endif; ?>
                                                        <?php if($errors->has('tempat')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('tempat')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>  
                                            </div>
        
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('luas') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Luas Lot')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
        
                                                        <input type="text"  name="luas" placeholder="<?php echo e($geran->luas_lot); ?>" value="<?php echo e($geran->luas_lot); ?>" class="form-control" maxlength="25" required>
                                                        <?php if($errors->has('luas')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('luas')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('kategori') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Kategori Penggunaan Tanah')); ?></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <?php if(!empty($geran->kategori_tanah)): ?>
                                                        <input type="text"  name="kategori" placeholder="<?php echo e($geran->kategori_tanah); ?>" value="<?php echo e($geran->kategori_tanah); ?>" class="form-control" maxlength="25" >
                                                        <?php else: ?>
                                                        <input type="text"  name="kategori" placeholder="<?php echo e(trans('Kategori Penggunaan Tanah')); ?>" value="<?php echo e(old('kategori')); ?>" class="form-control" maxlength="25" >
                                                        <?php endif; ?>
                                                        <?php if($errors->has('kategori')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('kategori')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>  
                                            </div>
        
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_lembaran') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Lembarang Piawai')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <?php if(!empty($geran->no_lembaran)): ?>
                                                        <input type="text"  name="no_lembaran" placeholder="<?php echo e($geran->no_lembaran); ?>" value="<?php echo e($geran->no_lembaran); ?>" class="form-control" maxlength="25" >
                                                        <?php else: ?>
                                                        <input type="text"  name="no_lembaran" placeholder="<?php echo e(trans('No. Lembarang Piawai')); ?>" value="<?php echo e(old('no_lembaran')); ?>" class="form-control" maxlength="25" >
                                                        <?php endif; ?>
                                                        <?php if($errors->has('no_lembaran')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('no_lembaran')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_pelan') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Pelan Diperakui')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text"  name="no_pelan" placeholder="<?php echo e($geran->no_pelan); ?>" value="<?php echo e($geran->no_pelan); ?>" class="form-control" maxlength="25" required>
                                                        <?php if($errors->has('no_pelan')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('no_pelan')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div> 
                                            </div>
        
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_fail') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Fail')); ?> <label class="text-danger">*</label> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text"  name="no_fail" placeholder="<?php echo e($geran->no_fail); ?>" value="<?php echo e($geran->no_fail); ?>" class="form-control" maxlength="25" required >
                                                        <?php if($errors->has('no_fail')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('no_fail')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
         
                                            </div>
                                            
                                            <div id="haksementara"  style="display: none;">
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_pt') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. PT')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <?php if(!empty($geran->no_pt)): ?>
                                                        <input type="text"  name="no_pt" placeholder="<?php echo e($geran->no_pt); ?>" value="<?php echo e($geran->no_pt); ?>" class="form-control" maxlength="25" >
                                                        <?php else: ?>
                                                        <input type="text"  name="no_pt" placeholder="<?php echo e(trans('No. PT')); ?>" value="<?php echo e(old('no_pt')); ?>" class="form-control" maxlength="25" >
                                                        <?php endif; ?>
                                                        <?php if($errors->has('no_pt')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('no_pt')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('no_permohonan') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Permohonan Ukur')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <?php if(!empty($geran->no_permohonan)): ?>
                                                        <input type="text"  name="no_permohonan" placeholder="<?php echo e($geran->no_permohonan); ?>" value="<?php echo e($geran->no_permohonan); ?>" class="form-control" maxlength="25" >
                                                        <?php else: ?>
                                                        <input type="text"  name="no_permohonan" placeholder="<?php echo e(trans('No. Permohonan Ukur')); ?>" value="<?php echo e(old('no_permohonan')); ?>" class="form-control" maxlength="25" >
                                                        <?php endif; ?>
                                                        <?php if($errors->has('no_permohonan')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('no_permohonan')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Tarikh</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('daftar') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Daftar')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        
                                                        <input type="text"  name="daftar" placeholder="<?php echo e(date('j F Y',strtotime($geran->tarikh_daftar))); ?>" value=" <?php echo e(date('j F Y',strtotime($geran->tarikh_daftar))); ?>" class="form-control" maxlength="25" required >
                                                        <?php if($errors->has('daftar')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('daftar')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
         
                                            </div>
                                            <div id="haksementaraa" style="display: none;">
                                              <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('tempoh') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tempoh Hakmilik')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                      <?php if(!empty($geran->tempoh)): ?>
                                                        <input type="date"  name="tempoh" placeholder="<?php echo e($geran->tempoh); ?>" value="<?php echo e($geran->tempoh); ?>" class="form-control" maxlength="25" >
                                                      <?php else: ?>
                                                      <input type="date"  name="tempoh" placeholder="<?php echo e(trans('Tempoh Hakmilik')); ?>" value="<?php echo e(old('tempoh')); ?>" class="form-control" maxlength="25" >
                                                      <?php endif; ?>
                                                        <?php if($errors->has('tempoh')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('tempoh')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                              </div>
          
                                              
          
                                              <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('keluaran') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Hakmilik Keluaran')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                      <?php if(!empty($geran->syarat)): ?>
                                                        <input type="date"  name="keluaran" placeholder="<?php echo e($geran->tarikh_keluaran); ?>" value="<?php echo e($geran->tarikh_keluaran); ?>" class="form-control" maxlength="100" >
                                                      <?php else: ?>
                                                        <input type="date"  name="keluaran" placeholder="<?php echo e(trans('Tarikh Hakmilik Keluaran')); ?>" value="<?php echo e(old('keluaran')); ?>" class="form-control" maxlength="100" >
                                                      <?php endif; ?>
                                                        <?php if($errors->has('keluaran')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('keluaran')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                              </div>
                                        </div>
                                      </div>
                                    </div>
  
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Rekod Ketuanpunyaan</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Pemilik')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text"  name="pemilik" placeholder="<?php echo e($geran->pemilik); ?>" value="<?php echo e($geran->pemilik); ?>" class="form-control"  >
                                                        <?php if($errors->has('pemilik')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('pemilik')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                                

                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No Kad Pengenalan')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12 input-group date">
                                                        <input type="text" id="ic"  name="ic" placeholder="<?php echo e($geran->ic); ?>" value="<?php echo e($geran->ic); ?>" class="form-control" maxlength="25" >
                                                        <?php if($errors->has('ic')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('ic')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                              <div class="row">  
                                                  <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                      <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Warganegara')); ?> <label class="text-danger">*</label></label>
                                                      <div class="col-md-8 col-sm-8 col-xs-12 input-group date">
                                                          <input type="text" id="warga"  name="warga" placeholder="<?php echo e($geran->warga_negara); ?>" value="<?php echo e($geran->warga_negara); ?>" class="form-control" maxlength="55" >
                                                          <?php if($errors->has('warga')): ?>
                                                          <span class="help-block text-danger" autofocus>
                                                              <strong><?php echo e($errors->first('warga')); ?></strong>
                                                          </span>
                                                          <?php endif; ?>
                                                      </div>
                                                  </div>


        
                                              </div>
                                              <div class="row">
                                                <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-9 col-sm-9 col-xs-12"" for="display-name"><?php echo e(trans('Alamat Pemilik')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-10 col-sm-10 col-xs-12 input-group date">
                                                        <textarea rows="5" cols="50" name="alamat" placeholder="<?php echo e($geran->alamat); ?>" value="<?php echo e($geran->alamat); ?>" class="form-control" ></textarea>
                                                        <?php if($errors->has('alamat')): ?>
                                                        <span class="help-block text-danger">
                                                            <strong><?php echo e($errors->first('alamat')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                              </div>

                                      </div>
                                    </div>

                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Syarat Geran</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('syarat') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Syarat-Syarat Nyata')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
      
                                                      <?php if(!empty($geran->syarat)): ?>
                                                        <input type="text"  name="syarat" placeholder="<?php echo e($geran->syarat); ?>" value="<?php echo e($geran->syarat); ?>" class="form-control" maxlength="500" >
                                                      <?php else: ?>
                                                      <input type="text"  name="syarat" placeholder="<?php echo e(trans('Syarat-syarat Nyata')); ?>" value="<?php echo e(old('syarat')); ?>" class="form-control" maxlength="500" >
                                                      <?php endif; ?>
                                                        <?php if($errors->has('syarat')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('syarat')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
         
                                            </div>
        
                                            <div class="row">  
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('kepentingan') ? ' has-error' : ''); ?> ">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
      
                                                        <?php if(!empty($geran->syarat_kepentingan)): ?>
                                                        <textarea rows="10" cols="50" name="kepentingan" placeholder="<?php echo e($geran->syarat_kepentingan); ?>" value="<?php echo e($geran->syarat_kepentingan); ?>" class="form-control" ></textarea>
                                                        <?php else: ?>
                                                        <textarea rows="10" cols="50" name="kepentingan" placeholder="<?php echo e(trans('cth:Geran Kod A dan B')); ?>" value="<?php echo e(old('kepentingan')); ?>" class="form-control"  ></textarea>
                                                        <?php endif; ?>
      
                                                        <?php if($errors->has('kepentingan')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('kepentingan')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
      
                                            </div>
                                        </div>
  
                                      
                                </div>

                                
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                            <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Batal')); ?></a>
                                            <button type="submit" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Mengemaskini')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
				</div>



<script>
    function myFunction() {
      var x = document.getElementById("tajuk").value;
      
      if ( x == "Hakmilik Sementara Daerah" || x == "Hakmilik Sementara Mukim" )
      {
          document.getElementById("haksementara").style.display = "block";
          document.getElementById("haksementaraa").style.display = "block";
      }
      else{
      document.getElementById("haksementara").style.display = "none";
      document.getElementById("haksementaraa").style.display = "none";
      
      }
    }
    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/failkes/edit.blade.php ENDPATH**/ ?>
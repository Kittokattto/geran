<?php $__env->startSection('title'); ?>
Tambah Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link"  style="margin-left: 8px;" >
                    
                            <a href="<?php echo url('/failkes/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Geran</b> </a>
                            <a href="<?php echo url('/failkes/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Geran</b></a>
                           
                        </nav>                    
                    </div>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content">
                                <?php if(session('error')): ?>
							<div class="alert alert-danger"><span class="fa fa-times"></span><em> <?php echo e(session('error')); ?> </em></div>
						<?php endif; ?>
                                <form id="demo-form2" action="<?php echo url('/failkes/store'); ?>" method="post"  enctype="multipart/form-data" data-parsley-validate class="form-horizontal form-label-left input_mask customerAddForm">
                                         <?php echo csrf_field(); ?>
                                         <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Geran</h6>
                                            </div>
                                            <div class="card-body">
    
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="tajuk"><?php echo e(trans('Jenis Geran')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <select name="tajuk" id="tajuk"  class="form-control" aria-placeholder="Pilih Jenis Geran" value="<?php echo e(old('tajuk')); ?>"  autocomplete="tajuk" >
                                                                
                                                                <option value="Geran">Geran</option>
                                                                <option value="Geran Mukim">Geran Mukim</option>
                                                                <option value="Pajakan">Pajakan</option>
                                                                <option value="Pajakan Mukim">Pajakan Mukim</option>
                                                                <option value="Hakmilik Sementara Daerah">Hakmilik Sementara Daerah</option>
                                                                <option value="Hakmilik Sementara Mukim">Hakmilik Sementara Mukim</option>
        
                                                            </select>
                                                            <?php if($errors->has('tajuk')): ?>
                                                                <span class="help-block text-danger" autofocus>
                                                                    <strong><?php echo e($errors->first('tajuk')); ?></strong>
                                                                </span>
                                                        <?php endif; ?>
                                                        </div>
                                                    </div>
                   
                                                   
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('No. Hakmilik')); ?> <label class="text-danger">*</label> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text" id="no_hakmilik" name="no_hakmilik"  class="form-control" value="<?php echo e(old('no_hakmilik')); ?>" placeholder="<?php echo e(trans(' No. Hakmilik/SementaraDaerah/SemantaraMunkim')); ?>" maxlength="25"    />
                                                        <?php if($errors->has('no_hakmilik')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('no_hakmilik')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                        
                                                        </div>
                                                    </div>
                                                </div>    
                
                                                <div class="row">
                                                 
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Cukai Tahunan')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <label class="control-label ">RM :</label><label class="control-label"><input type="text"  name="cukai" placeholder="<?php echo e(trans('')); ?>" value="<?php echo e(old('cukai')); ?>" class="form-control"    ></label>
                                                            <?php if($errors->has('cukai')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('cukai')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                
                                                </div>
    
                                                
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <div class="form-check">
                                                    
                                                    <div class="col-md-8 col-sm-8 col-xs-12 gender">
                                                        <input type="checkbox" id="rizab"  name="rizab" value="1" class="form-check-input" value="<?php echo e(old('rizab')); ?>">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12"> <?php echo e(trans('Rizab Melayu')); ?></label>
                                                    </div>
                                                    </div>
                                                </div>
    
                                                <div id="check"  style="display: none;">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Pemberitahuan Warta')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="text" id="warta"  name="warta" placeholder="<?php echo e(trans('')); ?>" value="<?php echo e(old('warta')); ?>" class="form-control" maxlength="25" >
                                                        <?php if($errors->has('warta')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('warta')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Pemberitahuan Warta')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <input type="date" id="tarikh_warta" name="tarikh_warta" placeholder="<?php echo e(trans('')); ?>" value="<?php echo e(old('tarikh_warta')); ?>" class="form-control" maxlength="25" >
                                                        <?php if($errors->has('tarikh_warta')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('tarikh_warta')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
    
                                                    </div>
                                                </div>
                                                </div>
                                    
    
    
                                            </div>
                                    </div>
    
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Maklumat Geran</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                 
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Negeri')); ?> <label class="text-danger">*</label> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <select name="negeri" id="negeri" class="form-control" placeholder="Sila Pilih Negeri" value="<?php echo e(old('negeri')); ?>"  autocomplete="negeri"   >
                                                                <option value="Johor">Johor</option>
                                                                <option value="Kedah">Kedah</option>
                                                                <option value="Kelantan">Kelantan</option>
                                                                <option value="Negeri Sembilan">Negeri Sembilan</option>
                                                                <option value="Pahang">Pahang</option>
                                                                <option value="Perak">Perak</option>
                                                                <option value="Perlis">Perlis</option>
                                                                <option value="Selangor">Selangor</option>
                                                                <option value="Terengganu">Terengganu</option>
                                                                <option value="Kuala Lumpur">Kuala Lumpur</option>
                                                                <option value="Melaka">Melaka</option>
                                                                <option value="Pulau Pinang">Pulau Pinang</option>
                                                                <option value="Sabah">Sabah</option>
                                                                <option value="Sarawak">Sarawak</option>
                                                              </select>
                                                            <?php if($errors->has('negeri')): ?>
                                                                <span class="help-block text-danger"autofocus>
                                                                    <strong><?php echo e($errors->first('negeri')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Daerah')); ?> <label class="text-danger">*</label> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                          <input type="text" id="daerah" name="daerah"  class="form-control"  
                                                          value="<?php echo e(old('daerah')); ?>" placeholder="<?php echo e(trans('Sila Isi Daerah')); ?>" maxlength="25"    />
                                                          <?php if($errors->has('daerah')): ?>
                                                           <span class="help-block text-danger" autofocus>
                                                               <strong><?php echo e($errors->first('daerah')); ?></strong>
                                                           </span>
                                                         <?php endif; ?>
                                                        </div>
                                                    </div>
                
                                                </div>
                                                <div class="row">
                                                 
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No.Lot')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="lot" placeholder="<?php echo e(trans('cth: 81000')); ?>" value="<?php echo e(old('lot')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('lot')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('lot')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback  ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tempat')); ?></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="tempat" placeholder="<?php echo e(trans('Alamat Geran')); ?>" value="<?php echo e(old('tempat')); ?>" class="form-control" maxlength="150" >
                                                            <?php if($errors->has('tempat')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('tempat')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
            
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Luas Lot')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="luas" placeholder="<?php echo e(trans('Sila Isi Luas Lot')); ?>" value="<?php echo e(old('luas')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('luas')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('luas')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Kategori Penggunaan Tanah')); ?></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="kategori" placeholder="<?php echo e(trans('Kategori Penggunaan Tanah')); ?>" value="<?php echo e(old('kategori')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('kategori')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('kategori')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
            
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Lembaran Piawai')); ?> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="no_lembaran" placeholder="<?php echo e(trans('No. Lembaran Piawai')); ?>" value="<?php echo e(old('no_lembaran')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('no_lembaran')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('no_lembaran')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback  ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Pelan Diperakui')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="no_pelan" placeholder="<?php echo e(trans('No. Pelan Diperakui')); ?>" value="<?php echo e(old('no_pelan')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('no_pelan')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('no_pelan')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
            
                                                <div class="row">  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Fail')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="no_fail" placeholder="<?php echo e(trans('No. Fail')); ?>" value="<?php echo e(old('no_fail')); ?>" class="form-control" maxlength="50" >
                                                            <?php if($errors->has('no_fail')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('no_fail')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
             
                                                </div>
                                                
                                                <div id="haksementara"  style="display: none;">
                                                <div class="row">  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. PT')); ?> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="no_pt" placeholder="<?php echo e(trans('No. PT')); ?>" value="<?php echo e(old('no_pt')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('no_pt')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('no_pt')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No. Permohonan Ukur')); ?> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="no_permohonan" placeholder="<?php echo e(trans('No. Permohonan Ukur')); ?>" value="<?php echo e(old('no_permohonan')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('no_permohonan')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('no_permohonan')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                        
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Tarikh</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Daftar')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12 date">
                                                            <input type="date"  name="daftar" placeholder="<?php echo e(trans('Tarikh Daftar')); ?>" value="<?php echo e(old('daftar')); ?>" class="form-control" maxlength="25"  />
                                                            <?php if($errors->has('daftar')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('daftar')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
             
                                                </div>
                                                <div id="haksementaraa" style="display: none;">
                                                  <div class="row">  
                                                      <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tempoh Hakmilik')); ?></label>
                                                          <div class="col-md-8 col-sm-8 col-xs-12">
                                                              <input type="date" id="tempoh"  name="tempoh" placeholder="<?php echo e(trans('Tempoh Hakmilik')); ?>" value="<?php echo e(old('tempoh')); ?>" class="form-control" maxlength="25" >
                                                              <?php if($errors->has('tempoh')): ?>
                                                              <span class="help-block text-danger" autofocus>
                                                                  <strong><?php echo e($errors->first('tempoh')); ?></strong>
                                                              </span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>
            
                                                  </div>
              
                                                  
              
                                                  <div class="row">  
                                                      <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Hakmilik Keluaran')); ?> <label class="text-danger">*</label></label>
                                                          <div class="col-md-8 col-sm-8 col-xs-12 input-group date">
                                                              <input type="date" id="keluaran"  name="keluaran" placeholder="<?php echo e(trans('Tarikh Hakmilik Keluaran')); ?>" value="<?php echo e(old('keluaran')); ?>" class="form-control" maxlength="25" >
                                                              <?php if($errors->has('keluaran')): ?>
                                                              <span class="help-block text-danger" autofocus>
                                                                  <strong><?php echo e($errors->first('keluaran')); ?></strong>
                                                              </span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>
            
                                                  </div>
                                            </div>
                                          </div>
                                        </div>
    
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Rekod Ketuanpunyaan</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Pemilik')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="pemilik" placeholder="<?php echo e(trans('Pemilik')); ?>" value="<?php echo e(old('pemilik')); ?>" class="form-control"  >
                                                            <?php if($errors->has('pemilik')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('pemilik')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
    
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('No Kad Pengenalan')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12 input-group date">
                                                            <input type="text" id="ic"  name="ic" placeholder="<?php echo e(trans(' cth:890302-01-****')); ?>" value="<?php echo e(old('ic')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('ic')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('ic')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                                  <div class="row">  
                                                      <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Warganegara')); ?> <label class="text-danger">*</label></label>
                                                          <div class="col-md-8 col-sm-8 col-xs-12 input-group date">
                                                              <input type="text" id="warga"  name="warga" placeholder="<?php echo e(trans('cth: Malaysia, Singapore eg..')); ?>" value="<?php echo e(old('warga')); ?>" class="form-control" maxlength="55" >
                                                              <?php if($errors->has('warga')): ?>
                                                              <span class="help-block text-danger" autofocus>
                                                                  <strong><?php echo e($errors->first('warga')); ?></strong>
                                                              </span>
                                                              <?php endif; ?>
                                                          </div>
                                                      </div>
    

            
                                                  </div>
                                                  <div class="row">
                                                    <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-9 col-sm-9 col-xs-12"" for="display-name"><?php echo e(trans('Alamat Pemilik')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-10 col-sm-10 col-xs-12 input-group date">
                                                            <textarea rows="5" cols="50" name="alamat" placeholder="<?php echo e(trans('Alamat Penuh')); ?>" value="<?php echo e(old('alamat')); ?>" autocomplete='alamat' class="form-control" ></textarea>
                                                            <?php if($errors->has('alamat')): ?>
                                                            <span class="help-block text-danger" autofocus>
                                                                <strong><?php echo e($errors->first('alamat')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                  </div>
    
                                          </div>
                                        </div>
      
                                          
    
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Syarat Geran</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">  
                                                    <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-9 col-sm-9 col-xs-12" for="display-name"><?php echo e(trans('Syarat-Syarat Nyata')); ?> </label>
                                                        <div class="col-md-10 col-sm-10 col-xs-12">
                                                            <input type="text"  name="syarat" placeholder="<?php echo e(trans('Syarat-syarat Nyata')); ?>" value="<?php echo e(old('syarat')); ?>" class="form-control" maxlength="100" >
                                                            <?php if($errors->has('syarat')): ?>
                                                            <span class="help-block text-danger">
                                                                <strong><?php echo e($errors->first('syarat')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
             
                                                </div>
            
                                                <div class="row">  
                                                    <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                        <label class="control-label col-md-9 col-sm-9 col-xs-12" for="display-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label>
                                                        <div class="col-md-10 col-sm-10 col-xs-12">
                                                            <textarea rows="10" cols="50" name="kepentingan" placeholder="<?php echo e(trans('cth:Geran Kod A dan B')); ?>" value="<?php echo e(old('kepentingan')); ?>" class="form-control" ></textarea>
                                                            <?php if($errors->has('kepentingan')): ?>
                                                            <span class="help-block text-danger">
                                                                <strong><?php echo e($errors->first('kepentingan')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
          
                                                </div>
                                            </div>
      
                                          
                                    </div>
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Rekod Urusan</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">  
                                                <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-9 col-sm-9 col-xs-12" for="display-name"><?php echo e(trans('Rekod Urusan Geran')); ?> </label>
                                                    <div class="col-md-10 col-sm-10 col-xs-12">
                                                        <textarea rows="10" cols="50" name="urusan" placeholder="<?php echo e(trans('Urusan Geran')); ?>" value="<?php echo e(old('urusan')); ?>" class="form-control"></textarea>
                                                            <?php if($errors->has('urusan')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('urusan')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                    </div>
                                                </div>
         
                                            </div>
    
                                        </div>
    
                                      
                                </div>
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Pelan Geran</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">  
                                                <div class="col-md-9 col-sm-9 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-9 col-sm-9 col-xs-12" for="display-name"><?php echo e(trans('Gambar Pelan')); ?> </label>
                                                    <div class="col-md-10 col-sm-10 col-xs-12">
                                                        <input type="file" id="file" name="file" placeholder="<?php echo e(trans('Syarat-syarat Nyata')); ?>" value="<?php echo e(old('file')); ?>"  >
                                                        <?php if($errors->has('file')): ?>
                                                        <span class="help-block text-danger" autofocus>
                                                            <strong><?php echo e($errors->first('file')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                        <?php if ($errors->has('max_upload')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('max_upload'); ?>
                                                        <div class="alert" id="create-news-alert-image"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    </div>
                                                </div>
         
                                            </div>
    
                                        </div>
    
                                      
                                </div>
    

                                
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                            <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Cancel')); ?></a>
                                            <button type="submit" id="sub-btn" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Submit')); ?></button>
                                        </div>
                                    </div>
                                
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
</div>
</div>
            
<?php if(session()->has('jsAlert')): ?>
    <script>
        alert(<?php echo e(session()->get('jsAlert')); ?>);
    </script>
<?php endif; ?> 

<script>
    document.addEventListener("DOMContentLoaded", function(event) {


                $('#tajuk').change(function(){

                var x = document.getElementById("tajuk").value;
                
                if ( x == "Hakmilik Sementara Daerah" || x == "Hakmilik Sementara Mukim" )
                {
                    document.getElementById("haksementara").style.display = "block";
                    document.getElementById("haksementaraa").style.display = "block";
                    //   document.getElementById("haksementara3").style.display = "block";
                }
                else{
                document.getElementById("haksementara").style.display = "none";
                //   document.getElementById("haksementara3").style.display = "none";
                document.getElementById("haksementaraa").style.display = "none";
                
                }
             });

             $('#rizab').change(function(){

                var checkBox = document.getElementById("rizab");
                    var text = document.getElementById("check");
                    if (checkBox.checked == true){
                        text.style.display = "block";
                        document.getElementById("warta").required =true;
                        document.getElementById("tarikh_warta").required = true;
                    } else {
                        text.style.display = "none";
                        document.getElementById("warta").required =false;
                        document.getElementById("tarikh_warta").required = false;
                     }
            });


    });
</script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views//failkes/tambah.blade.php ENDPATH**/ ?>
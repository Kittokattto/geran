<?php $__env->startSection('title'); ?>
Senarai Tugasan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<?php if(getAccessStatusUser()=='yes'): ?>
<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">
			
			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >
						<div class="card mb-4 py-3 border-bottom-secondry">
						<nav class="tab-link" style="margin-left: 8px;">
					
							<a href="<?php echo url('/tugas/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Tugas Selesai</b> </a>
							<a href="<?php echo url('/tugas/senaraiselesai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Tugas Tidak Selesai</b> </a>
							<a href="<?php echo url('/tugas/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Tambah Tugas</b> </a>

						</nav>
						</div>
					
					<?php if(session('message')): ?>
				<div class="row message">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class=" bg-success text-white shadow">
							<div class="row justify-content-center"> <?php echo e(session('message')); ?>  </div>
						    
						</div>
					</div>
				</div>
				<?php endif; ?>
					

					
					
					<div class="table-wrapper">
						
						<table class="fl-table" >
							
							<thead>
								<tr>
									

									<th><?php echo e(trans('Keutamaan')); ?></th>
									<th><?php echo e(trans('Nama Kakitangan')); ?></th>
                                    <th><?php echo e(trans('Tugasan')); ?></th>
                                    <th><?php echo e(trans('Tugasan Oleh')); ?></th>
									<th><?php echo e(trans('Tarikh Mula')); ?></th> 
									<th><?php echo e(trans('Tarikh Akhir')); ?></th> 
									<th><?php echo e(trans('Masa')); ?></th>
									<th><?php echo e(trans('Tindakan')); ?></th>
								</tr>
							</thead>
							<tbody>
                                <?php if(!empty($task)): ?>
								<?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										
										<td>
											<?php if($tasks->keutamaan == '1'): ?>
											<?php echo e(trans('Sangat Penting')); ?>

											<?php elseif($tasks->keutamaan == '2'): ?>
											<?php echo e(trans('Penting')); ?>

											<?php else: ?> 
											<?php echo e(trans('Tidak Penting')); ?>

											<?php endif; ?>
										</td>
										<td><?php echo e($tasks->staff->name); ?></td>
										<td>
											
											<?php echo e(getLength($tasks->tugas)); ?>

										</td>
                                        <td><?php echo e($tasks->tugasBy); ?></td>
                                        <td><?php echo e(date('j F Y',strtotime($tasks->created_at))); ?></td>
                                        <td><?php echo e(date('j F Y',strtotime($tasks->tarikh))); ?></td>
                                        <td><?php echo e($tasks->masa); ?></td>

										<td>

												<a href="<?php echo url('/tugas/show/'.$tasks->id); ?>"><button type="button" class="btn btn-round btn-info"><?php echo e(trans('Lihat')); ?></button></a>
												<a href="<?php echo url('/tugas/edit/'.$tasks->id); ?>" ><button type="button" class="btn btn-round btn-success"><?php echo e(trans('Mengemaskini')); ?></button></a>
												<a url="<?php echo url('/tugas/padam/'.$tasks->id); ?>" class="sa-warning buttonOfAtag"><button type="button" id="threeBtnInOneLine" class="btn btn-round btn-danger "><?php echo e(trans('Padam')); ?></button></a>

										</td>
									</tr>
					
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</tbody>
						</table>
						
					</div>
					
				</div>
			</div>
		</div>
	</div>

	<?php else: ?>
	<div class="right_col" role="main">
		<div class="nav_menu main_title" style="margin-top:4px;margin-bottom:15px;">
            <div class="nav toggle" style="padding-bottom:16px;">
				<span class="titleup">&nbsp <?php echo e(trans('You are not authorize this page.')); ?></span>
            </div>
		</div>
	</div>
	<?php endif; ?>



	
<script>
	document.addEventListener("DOMContentLoaded", function(event) {
	$('body').on('click', '.sa-warning', function() {
	
		var url =$(this).attr('url');
		
		
		 	Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it!'
			}).then((result) => {
				if (result.value) {
					window.location.href = url;
					Swal.fire(
					'Deleted!',
					'Your imaginary file has been deleted.',
					'success'
					)
				// For more information about handling dismissals please visit
				// https://sweetalert2.github.io/#handling-dismissals
				} else if (result.dismiss === Swal.DismissReason.cancel) {
					Swal.fire(
					'Cancelled',
					'Your imaginary file is safe :)',
					'error'
					)
				}
				})
	  }); 
  } );

// $('body').on('click', '.sa-warning', function() {
	
// 	var url =$(this).attr('url');
	
	
// 	  swal({   
// 		  title: "Are You Sure?",
// 		  text: "You will not be able to recover this data afterwards!",   
// 		  type: "warning",   
// 		  showCancelButton: true,   
// 		  confirmButtonColor: "#297FCA",   
// 		  confirmButtonText: "Yes, delete!",   
// 		  closeOnConfirm: false 
// 	  }, function(){
// 		  window.location.href = url;
		   
// 	  });
//   }); 
// } );
   
  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views//tugas/senaraiadmin.blade.php ENDPATH**/ ?>
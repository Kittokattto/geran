<?php $__env->startSection('title'); ?>
Tambah Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link"  style="margin-left: 8px;" >
                    
                            <a href="<?php echo url('/tugas/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Tugas</b> </a>
                            <a href="<?php echo url('/tugas/senaraiselesai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Tugas Tidak Selesai</b> </a>
                            <a href="<?php echo url('/tugas/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Tugas</b></a>
                           
                        </nav>                    
                    </div>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content">
                                <?php if(session('error')): ?>
							<div class="alert alert-danger"><span class="fa fa-times"></span><em> <?php echo e(session('error')); ?> </em></div>
						<?php endif; ?>
                                <form id="demo-form2" action="<?php echo url('/tugas/store'); ?>" method="post"  enctype="multipart/form-data" data-parsley-validate class="form-horizontal form-label-left input_mask customerAddForm">
                                         <?php echo csrf_field(); ?>
                                <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Tugasan</h6>
                                        </div>
                                        <div class="card-body">

                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"><?php echo e(trans('Tajuk')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        
                                                            <input type="text" id="title" name="title" placeholder="<?php echo e(trans('Tajuk')); ?>" value="<?php echo e(old('title')); ?>" class="form-control" maxlength="25" >
                                                            <?php if($errors->has('title')): ?>
                                                            <span class="help-block text-danger" >
                                                                <strong><?php echo e($errors->first('title')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                    </div>
                                                </div>
               
                                               
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Keutamaan')); ?> <label class="text-danger">*</label> </label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <select name="priority" id="priority" class="form-control" placeholder="" value="<?php echo e(old('priority')); ?>"  autocomplete="negeri"   >
                                                            <option value="" disabled selected hidden >Keutamaan</option>
                                                            <option value="1" style="color: rgb(255, 37, 9);" >High</option>
                                                            <option value="2" style="color: rgb(255, 255, 0);">Medium</option>
                                                            <option value="3" style="color: rgb(20, 247, 93);"">Low</option>
                                                            
                                                          </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="tajuk"><?php echo e(trans('Nama Staf')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-8 col-sm-8 col-xs-12">
                                                        <select name="staf" id="staf"  class="form-control" value="<?php echo e(old('staff')); ?>"  autocomplete="tajuk" >
                                                            <option value="" disabled selected hidden>Staff</option>
                                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            
												            <option value="<?php echo e($user->id); ?>" ><?php echo e($user->name); ?></option>
											                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                        </select>
                                                        <?php if($errors->has('tajuk')): ?>
                                                            <span class="help-block text-danger" >
                                                                <strong><?php echo e($errors->first('tajuk')); ?></strong>
                                                            </span>
                                                    <?php endif; ?>
                                                    </div>
                                                </div>
            
                                            </div>   
            
                                            <div class="row">
                                             
                                                <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                                                    <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tugasan')); ?> <label class="text-danger">*</label></label>
                                                    <div class="col-md-10 col-sm-10 col-xs-12">
                                                        <textarea  name="tugas" rows="10" cols="40" placeholder="<?php echo e(trans('Tugasan')); ?>" value="<?php echo e(old('tugas')); ?>" class="form-control"  ></textarea>
                                                        <?php if($errors->has('tugas')): ?>
                                                        <span class="help-block text-danger" >
                                                            <strong><?php echo e($errors->first('tugas')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </div>
                                            
                                            </div>
                                            <div class="row">
                                            <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Akhir')); ?> <label class="text-danger">*</label></label>
                                                <div class="col-md-8 col-sm-8 col-xs-12">
                                                    <input type="date" id="tarikh" name="tarikh" placeholder="<?php echo e(trans('Tarikh hantar')); ?>" value="<?php echo e(old('tarikh')); ?>" class="form-control" maxlength="25" >
                                                    <?php if($errors->has('tarikh')): ?>
                                                    <span class="help-block text-danger" >
                                                        <strong><?php echo e($errors->first('tarikh')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                            

                                        </div>
                                            

                                            
                                                    
                                                
                                


                                </div>
                                
                                
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                            <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Cancel')); ?></a>
                                            <button type="submit" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Submit')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
				</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/tugas/tambah.blade.php ENDPATH**/ ?>
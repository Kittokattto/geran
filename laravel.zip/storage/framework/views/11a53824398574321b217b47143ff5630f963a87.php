<?php $__env->startSection('title'); ?>
Tambah Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link" >
                    
                            <a href="<?php echo url('/lokasi/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Lokasi</b> </a>
							<a href="<?php echo url('/lokasi/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Lokasi Fail</b></a>
                            <a href="<?php echo url('/failkes/edit/'.$lokasi->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Mengemaskini Lokasi Fail</b></a>
                        </nav>                    
                    </div>
                    
                    <div class="linklocation">
                        <span class="tutupbtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                        <strong>Untuk mengemaskini maklumat fail perlu ke senarai geran !</strong>
                        
                      </div>
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content">
                                <form id="demo-form2" action="update/<?php echo e($lokasi->id); ?>" method="post" 
                                enctype="multipart/form-data" data-parsley-validate 
                                         class="form-horizontal form-label-left input_mask customerAddForm">
                                         <?php echo csrf_field(); ?>
                                         <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-primary">Maklumat Lokasi Fail</h6>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                 
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('tajuk') ? ' has-error' : ''); ?>">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Tajuk Fail')); ?> <label class="text-danger">*</label> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                          <input type="text" id="tajuk" name="tajuk" placeholder="<?php echo e($lokasi->tajuk_file); ?>"  class="form-control validate[required]" value="<?php echo e($lokasi->tajuk_file); ?>" maxlength="25"  required  />
                                                          <?php if($errors->has('tajuk')): ?>
                                                           <span class="help-block">
                                                               <strong><?php echo e($errors->first('tajuk')); ?></strong>
                                                           </span>
                                                         <?php endif; ?>
                                                        </div>
                                                    </div>
                  
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('jenis') ? ' has-error' : ''); ?>">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name"><?php echo e(trans('Jenis Fail')); ?> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                          <input type="text" id="jenis" name="jenis"   class="form-control "  placeholder="<?php echo e($lokasi->jenis_file); ?>" value="<?php echo e($lokasi->jenis_file); ?>"  maxlength="25"  />
                                                          <?php if($errors->has('jenis')): ?>
                                                           <span class="help-block">
                                                               <strong><?php echo e($errors->first('jenis')); ?></strong>
                                                           </span>
                                                         <?php endif; ?>
                                                        </div>
                                                    </div>
                
                                                </div>
                                                <div class="row">
                                                 
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('lokasi') ? ' has-error' : ''); ?> ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Lokasi Fail')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="lokasi"  placeholder="<?php echo e($lokasi->lokasi); ?>" value="<?php echo e($lokasi->lokasi); ?>" class="form-control" maxlength="25" required>
                                                            <?php if($errors->has('lokasi')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('lokasi')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('kod') ? ' has-error' : ''); ?> ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Kod Fail')); ?> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="kod" placeholder="<?php echo e($lokasi->kod); ?>" value="<?php echo e($lokasi->kod); ?>" class="form-control" maxlength="150" >
                                                            <?php if($errors->has('kod')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('kod')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
            
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('copy') ? ' has-error' : ''); ?> ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Jumlah Salinan')); ?> <label class="text-danger">*</label></label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="copy" placeholder="<?php echo e($lokasi->copy); ?>" value="<?php echo e($lokasi->copy); ?>" class="form-control" maxlength="25" required>
                                                            <?php if($errors->has('copy')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('copy')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
            
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('status') ? ' has-error' : ''); ?> ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Status Fail')); ?>  <label class="text-danger">*</label> </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="text"  name="status" placeholder="<?php echo e($lokasi->status); ?>" value="<?php echo e($lokasi->status); ?>" class="form-control" maxlength="25" required >
                                                            <?php if($errors->has('status')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('status')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div> 
                                                </div>
            
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback <?php echo e($errors->has('date') ? ' has-error' : ''); ?> ">
                                                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="display-name"><?php echo e(trans('Tarikh Disimpan')); ?>  <label class="text-danger">*</label>  </label>
                                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                                            <input type="date"  name="date" placeholder="<?php echo e($lokasi->date_locate); ?>" value="<?php echo e($lokasi->date_locate); ?>" class="form-control" maxlength="25" required>
                                                            <?php if($errors->has('date')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('date')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    
                                                </div> 
                                            </div>
                                        </div>


                                        
                                   

                                
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                            <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Batal')); ?></a>
                                            <button type="submit" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Mengemaskini')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
				</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/lokasi/edit.blade.php ENDPATH**/ ?>
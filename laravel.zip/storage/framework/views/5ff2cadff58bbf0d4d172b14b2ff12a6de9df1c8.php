<?php $__env->startSection('title'); ?>
Senarai Tugasan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">
			
			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >
					<div class="card mb-4 py-3 border-bottom-secondry">
						

						<nav class="tab-link" style="margin-left: 8px;" >
					
							<a href="<?php echo url('/tugas/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Tugas</b> </a>
							<a href="<?php echo url('/tugas/senaraiselesai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Senarai Tugas Selesai</b></a>
						</nav>
					
					</div>
					<?php if(session('message')): ?>
				<div class="row message">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class=" bg-success text-white shadow">
							<div class="row justify-content-center"> <?php echo e(session('message')); ?>  </div>
						    
						</div>
					</div>
				</div>
				<?php endif; ?>
					<div class="container page-todo bootstrap snippets bootdeys">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="task-list">
								<h1>Tasks</h1>
								<div class="card shadow mb-4">
								<div class="priority high"><span>high priority</span></div>

								<?php if(!empty($high)): ?>
								<?php $__currentLoopData = $high; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo url('/tugas/show/'.$highs->id); ?>">
								<div class="task high">
									<div class="desc">
										<div class="title"><?php echo e($highs->title); ?></div>
										<div>
											
											<?php echo e(getLength($highs->tugas)); ?>

										</div>
									</div>
									<div class="time">
										<div class="date"><?php echo e(date('j F Y',strtotime($highs->tarikh))); ?></div>
										<div> 1 day</div>
									</div>
								</div>	
								</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>							
								<?php endif; ?>

								
								<div class="priority medium"><span>medium priority</span></div>
								
								<?php if(!empty($medium)): ?>
								<?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediums): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo url('/tugas/show/'.$mediums->id); ?>">
								<div class="task medium">
									<div class="desc">
										<div class="title"><?php echo e($mediums->title); ?></div>
										<div><?php echo e($mediums->tugas); ?></div>
									</div>
									<div class="time">
										<div class="date"><?php echo e(date('j F Y',strtotime($mediums->tarikh))); ?></div>
										<div> 1 day</div>
									</div>
								</div>
								</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
						
								<div class="priority low"><span>low priority</span></div>
								
								<?php if(!empty($low)): ?>
								<?php $__currentLoopData = $low; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo url('/tugas/show/'.$lows->id); ?>">
								<div class="task low">
									<div class="desc">
										<div class="title"><?php echo e($lows->title); ?></div>
										<div><?php echo e($lows->tugas); ?></div>
									</div>
									<div class="time">
										<div class="date"><?php echo e(date('j F Y',strtotime($lows->tarikh))); ?></div>
										<div> 1 day</div>
									</div>
								</div>
								</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>

								

								<div class="clearfix"></div>		
							</div>
							</div>		
						</div>
						</div>
					
				</div>
			</div>
		</div>
	</div>

	



	
<script>
	document.addEventListener("DOMContentLoaded", function(event) {
	$('body').on('click', '.sa-warning', function() {
	
		var url =$(this).attr('url');
		
		
		 	Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it!'
			}).then((result) => {
				if (result.value) {
					window.location.href = url;
					Swal.fire(
					'Deleted!',
					'Your imaginary file has been deleted.',
					'success'
					)
				// For more information about handling dismissals please visit
				// https://sweetalert2.github.io/#handling-dismissals
				} else if (result.dismiss === Swal.DismissReason.cancel) {
					Swal.fire(
					'Cancelled',
					'Your imaginary file is safe :)',
					'error'
					)
				}
				})
	  }); 
  } );

// $('body').on('click', '.sa-warning', function() {
	
// 	var url =$(this).attr('url');
	
	
// 	  swal({   
// 		  title: "Are You Sure?",
// 		  text: "You will not be able to recover this data afterwards!",   
// 		  type: "warning",   
// 		  showCancelButton: true,   
// 		  confirmButtonColor: "#297FCA",   
// 		  confirmButtonText: "Yes, delete!",   
// 		  closeOnConfirm: false 
// 	  }, function(){
// 		  window.location.href = url;
		   
// 	  });
//   }); 
// } );
   
  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views//tugas/senaraiselesai.blade.php ENDPATH**/ ?>
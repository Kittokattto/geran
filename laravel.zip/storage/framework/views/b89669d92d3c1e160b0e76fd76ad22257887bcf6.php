<?php $__env->startSection('title'); ?>
<div class="card-header" style="margin-left: 8px;" ><h3>Senarai Pengguna</h3></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<?php if(getAccessStatusUser()=='yes'): ?>
<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">
			<?php if(session('message')): ?>
				<div class="row massage">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="checkbox checkbox-success checkbox-circle">
							<?php if(session('message') == 'Successfully Submitted'): ?>
							<label for="checkbox-10 colo_success"> <?php echo e(trans('Successfully Submitted')); ?>  </label>
						   <?php elseif(session('message')=='Successfully Updated'): ?>
						   <label for="checkbox-10 colo_success"> <?php echo e(trans('app.Successfully Updated')); ?>  </label>
						   <?php elseif(session('message')=='Successfully Deleted'): ?>
						   <label for="checkbox-10 colo_success"> <?php echo e(trans('app.Successfully Deleted')); ?>  </label>
						   <?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >
					<div class="x_content" style="background-color: black; color:white; length:100%;  border-radius:5px;">
						<ul class="nav nav-tabs bar_tabs" role="tablist">
						
                            <li role="presentation" class="active"><a href="<?php echo url('/pengguna/senarai'); ?>"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Nama Pengguna</b> </a></li>
                            <li role="presentation" class=""><a href="<?php echo url('/pengguna/tambah'); ?>"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Pengguna</b></a></li>

						</ul>
					</div>
					<?php $userid = Auth::user()->id; ?>
					<div class="table-wrapper">
						<table class="fl-table" style="margin-top:40px;">
							<thead>
								<tr>
									<th>#</th>

									<th><?php echo e(trans('Nama')); ?></th>
                                    <th><?php echo e(trans('No Telefon')); ?></th>
                                    <th><?php echo e(trans('Email')); ?></th>
									<th><?php echo e(trans('Alamat')); ?></th> 
									<th><?php echo e(trans('Jabatan')); ?></th>
                                    <th><?php echo e(trans('Didaftar Oleh')); ?></th>
                                    <th><?php echo e(trans('Tarikh Mendaftar')); ?></th> 
									<th><?php echo e(trans('Tindakan')); ?></th> 
								</tr>
							</thead>
							<tbody>
                                <?php if(!empty($user)): ?>
								<?php $i=1;?> 
								<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($i); ?></td>
										<td><?php echo e($users->name); ?></td>
										<td><?php echo e($users->phone); ?></td>
                                        <td><?php echo e($users->email); ?></td>
                                        <td><?php echo e($users->address); ?></td>
                                        <td><?php echo e($users->department); ?></td>
                                        <td><?php echo e($users->registerBy); ?></td>
                                        <td><?php echo e($users->created_at); ?></td>
										<td>

												<a href="<?php echo url('/pengguna/show/'.$users->id); ?>"><button type="button" class="btn btn-round btn-info"><?php echo e(trans('View')); ?></button></a>
												<a href="<?php echo url('/pengguna/edit/'.$users->id); ?>" ><button type="button" class="btn btn-round btn-success"><?php echo e(trans('Edit')); ?></button></a>
												<a url="<?php echo url('/pengguna/delete/'.$users->id); ?>" class="sa-warning buttonOfAtag"><button type="button" id="threeBtnInOneLine" class="btn btn-round btn-danger "><?php echo e(trans('Delete')); ?></button></a>

										</td>
									</tr>
								<?php $i++; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php else: ?>
	<div class="right_col" role="main">
		<div class="nav_menu main_title" style="margin-top:4px;margin-bottom:15px;">
            <div class="nav toggle" style="padding-bottom:16px;">
				<span class="titleup">&nbsp <?php echo e(trans('You are not authorize this page.')); ?></span>
            </div>
		</div>
	</div>
	<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PSM\resources\views/pengguna/senarai.blade.php ENDPATH**/ ?>
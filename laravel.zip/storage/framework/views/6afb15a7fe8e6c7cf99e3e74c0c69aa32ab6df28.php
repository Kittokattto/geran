<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Row -->
<div class="row">
    
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Jumlah Fail</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($geran); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-folder fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Pengguna</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($pengguna); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Perkembangan Tugas
                        </div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e($percent); ?>%</div>
                            </div>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar"
                                        style="width: <?php echo e($percent); ?>%" aria-valuenow="<?php echo e($percent); ?>" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Fail yang di tanda</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($jumlah_book); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-bookmark fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Content Row -->

<div class="row">

    <!-- Area Chart -->
    <div class="col-xl-8 col-lg-8">
        <div class="card shadow mb-4" >
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Fail Terkini</h6>
                <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                        aria-labelledby="dropdownMenuLink">
                        <div class="dropdown-header">Dropdown Header:</div>
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </div>
            </div>
            <!-- Card Body -->
            <div class="card-body" >
                
                <div class="table-responsive" id="proTeamScroll" tabindex="2" style="height: overflow: hidden; outline: none;">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No. HM</th>
                            <th>Jenis Geran</th>
                            <th>No. Lot</th>
                            <th>No. Pelan</th>
                            <th>No. Fail</th>
                            <th>Tarikh Daftar</th>
                            <th>Didaftar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($fail)): ?>
                        <?php $__currentLoopData = $fail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($fails->no_hakmilik); ?>

                            </td>
                            <td>
                                <h6 class="mb-0 font-13"><?php echo e($fails->tajuk_geran); ?></h6>
                                
                            </td>
                            <td><?php echo e($fails->no_lot); ?></td>
                            <td>
                                <?php echo e($fails->no_pelan); ?>

                            </td>
                            <td>
                                <div class="badge-outline col-red"><?php echo e($fails->no_fail); ?></div>
                            </td>
                            <td >
                                <?php echo e($fails->tarikh_daftar); ?>

                            </td>
                            <td>
                                <a href="<?php echo url('/failkes/show/'.$fails->geran_id); ?>"><button type="button" class="btn btn-round btn-info"><?php echo e(trans('View')); ?></button></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                        
                        

                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>

    <!-- Pie Chart -->
    <div class="col-xl-4 col-lg-4">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Pengguna Baharu</h6>
                <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                        aria-labelledby="dropdownMenuLink">
                        <div class="dropdown-header">Dropdown Header:</div>
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </div>
            </div>
            <!-- Card Body -->
            <div class="card-body">

                

            <table class="mb-0 table table-hover user-dashboard-info-box ">
                <thead>
                    <tr >

                        <th class="align-middle bt-0">Nama Pekerja </th>
                        <th class="align-middle bt-0">Status</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($user)): ?>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="candidates-list">

                       
                            <td class="title">
                              <div class="thumb">
                                <img  class="img-fluid" src="<?php echo e(asset('storage/'. $users->gambar)); ?>">
                              </div>
                              <div class="candidate-list-details">
                                <div class="candidate-list-info">
                                  <div class="candidate-list-title">
                                    <h6 class="mb-0"><a href="<?php echo url('/pengguna/show/'.$users->id); ?>"><?php echo e(getssmallLength($users->name)); ?></a></h6>
                                  </div>
                                  <div class="candidate-list-option">
                                    <ul class="list-unstyled">
                                      <li><i class="fas fa-filter pr-1"></i><?php echo e($users->department); ?></li>
                                      <li><i class="fas fa-map-marker-alt pr-1"></i><?php echo e(getssmallLength($users->address)); ?></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td class="align-middle">
                                <div class="mb-2 progress" style="height: 5px;">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%;"></div>
                                </div>
                                <div>Tasks Completed:<span class="text-inverse">36/94</span></div>
                            </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                 

                </tbody>
            </table>


        </div>
    </div>
</div>

<!-- Content Row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/home.blade.php ENDPATH**/ ?>
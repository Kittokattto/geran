<?php $__env->startSection('title'); ?>
Senarai Lokasi Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>

<form action="<?php echo url('/failkes/search'); ?>"  name="searchForm"   onsubmit="return validateForm()"method="get" class="d-none d-sm-inline-block shadow-sm">
<div class="input-group">
	<select name="type" id class="form-control  bg-light border-right-2 ">
		
		<option value="jenis_file" selected>Jenis Fail</option>
		<option value="tajuk_file">Tajuk Fail</option>
		<option value="status">Status</option>
		<option value="lokasi">Lokasi</option>
		
		
	</select>

	<hr>
	<input type="search" id="search" name="search"class="form-control bg-light border-0 small" placeholder="Cari Tajuk Fail..."
		aria-label="Search" aria-describedby="basic-addon2">
	<div class="input-group-append">
		<button class="btn btn-primary" type="submit">
			<i class="fas fa-search fa-sm"></i>
		</button>
	</div>
</div>
</form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">
			
			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >
					<div class="card mb-4 py-3 border-bottom-secondry">
						

						<nav class="tab-link" style="margin-left: 8px;" >
					
							<a href="<?php echo url('/lokasi/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Lokasi</b> </a>
							<a href="<?php echo url('/lokasi/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Lokasi Fail</b></a>

						</nav>
					
					
				</div>
				<?php if(session('message')): ?>
				<div class="row message">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class=" bg-success text-white shadow">
							<div class="row justify-content-center"> <?php echo e(session('message')); ?>  </div>
						    
						</div>
					</div>
				</div>
				<?php endif; ?>
					<?php $userid = Auth::user()->id; ?>
					<div style="margin:auto;"><?php echo e($lokasi->links()); ?></div>
					
					<div class="table-wrapper">
						
						<table class="fl-table" >
							
							<thead>
								<tr>
									<th>#</th>

									<th><?php echo e(trans('Jenis Fail')); ?></th>
									<th><?php echo e(trans('Tajuk Fail')); ?></th>
									
                                    <th><?php echo e(trans('Lokasi')); ?></th>
									<th><?php echo e(trans('Status')); ?></th>
									<th><?php echo e(trans('Jumlah Salinan')); ?></th> 
                                    <th><?php echo e(trans('Ditempatkan Oleh')); ?></th>
                                    <th><?php echo e(trans('Tarikh Ditempatkan')); ?></th> 
									<th><?php echo e(trans('Tindakan')); ?></th> 
									
								</tr>
							</thead>
							<tbody>
                                <?php if(!empty($lokasi)): ?>
								<?php $i=1;?> 
								<?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($i); ?></td>
										<td><?php echo e($lokasis->jenis_file); ?></td>
										<td><?php echo e($lokasis->tajuk_file); ?></td>
										
										<td><?php echo e($lokasis->lokasi); ?></td>
										<td><?php echo e($lokasis->status); ?></td>
                                        <td><?php echo e($lokasis->copy); ?></td>
                                        <td><?php echo e($lokasis->user->name); ?></td>
                                        <td><?php echo e($lokasis->created_at); ?></td>
                                        
										<td>

												<a href="<?php echo url('/lokasi/show/'.$lokasis->id); ?>"><button type="button" class="btn btn-round btn-info"><?php echo e(trans('View')); ?></button></a>
												<a href="<?php echo url('/lokasi/edit/'.$lokasis->id); ?>" ><button type="button" class="btn btn-round btn-success"><?php echo e(trans('Edit')); ?></button></a>
												<a url="<?php echo url('/lokasi/padam/'.$lokasis->id); ?>" class="sa-warning buttonOfAtag"><button type="button" id="threeBtnInOneLine" class="btn btn-round btn-danger "><?php echo e(trans('Delete')); ?></button></a>

										</td>
									</tr>
								<?php $i++; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</tbody>
						</table>
						
					</div>
					
				</div>
			</div>
		</div>
	</div>





	
<script>
	document.addEventListener("DOMContentLoaded", function(event) {
	$('body').on('click', '.sa-warning', function() {
	
		var url =$(this).attr('url');
		
		
		 	Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it!'
			}).then((result) => {
				if (result.value) {
					window.location.href = url;
					Swal.fire(
					'Deleted!',
					'Your imaginary file has been deleted.',
					'success'
					)
				// For more information about handling dismissals please visit
				// https://sweetalert2.github.io/#handling-dismissals
				} else if (result.dismiss === Swal.DismissReason.cancel) {
					Swal.fire(
					'Cancelled',
					'Your imaginary file is safe :)',
					'error'
					)
				}
				})
	  }); 
  } );

// $('body').on('click', '.sa-warning', function() {
	
// 	var url =$(this).attr('url');
	
	
// 	  swal({   
// 		  title: "Are You Sure?",
// 		  text: "You will not be able to recover this data afterwards!",   
// 		  type: "warning",   
// 		  showCancelButton: true,   
// 		  confirmButtonColor: "#297FCA",   
// 		  confirmButtonText: "Yes, delete!",   
// 		  closeOnConfirm: false 
// 	  }, function(){
// 		  window.location.href = url;
		   
// 	  });
//   }); 
// } );
   
  </script>
<script>
	function validateForm()
	{
		var x = document.forms["searchForm"]["search"].value;

		if (x == null| x == "")
		{
		
			return false;
		}
	
	}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/lokasi/senarai.blade.php ENDPATH**/ ?>
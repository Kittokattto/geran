<?php $__env->startSection('title'); ?>
<div class="card-header" style="margin-left: 8px;" ><h3>Senarai Pengguna</h3></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">
			
			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >
					<div class="x_content" style="background-color: black; color:white; length:100%;">
						<ul class="nav nav-tabs bar_tabs" role="tablist">

                            <li role="presentation" class="active"><a href="<?php echo url('/pengguna/senarai'); ?>"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Nama Pengguna</b> </a></li>
                            <li role="presentation" class=""><a href="<?php echo url('/pengguna/tambah'); ?>"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Pengguna</b></a></li>

						</ul>
					</div>
					<div class="x_panel table_up_div">
						<table id="datatable" class="table table-striped jambo_table" style="margin-top:20px;">
							<thead>
								<tr>
									<th>#</th>
									<th><?php echo e(trans('No')); ?></th>
									<th><?php echo e(trans('Nama')); ?></th>
									<th><?php echo e(trans('Alamat')); ?></th> 
									<th><?php echo e(trans('No Telefon')); ?></th>
									<th><?php echo e(trans('Jabatan')); ?></th>
                                    <th><?php echo e(trans('Tarikh Mendaftar')); ?></th> 
								</tr>
							</thead>
							<tbody>
			
								
								</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fileManagement2\resources\views//pengguna/senarai.blade.php ENDPATH**/ ?>
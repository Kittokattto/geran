<?php $__env->startSection('title'); ?>
Tambah Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link"  style="margin-left: 8px;" >
                    
                            <a href="<?php echo url('/lokasi/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Senarai Lokasi</b> </a>
							<a href="<?php echo url('/lokasi/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tambah Lokasi Fail</b></a>
                           
                        </nav>                    
                    </div>

                    <div class="linklocation">
                        <span class="tutupbtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                        <strong>Maklumat Geran ada dalam Pengkalan Data</strong> Indicates a dangerous or potentially negative action.
                      </div>

                    <div class="row justify-content-center">
                        <div class="col-md-10">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content"> 
                                <?php if(session('error')): ?>
							<div class="alert alert-danger"><span class="fa fa-times"></span><em> <?php echo e(session('error')); ?> </em></div>
						    <?php endif; ?>
                                <form id="demo-form2" action="<?php echo url('/lokasi/store'); ?>" method="post" 
                                enctype="multipart/form-data" data-parsley-validate 
                                         class="form-horizontal form-label-left input_mask customerAddForm">
                                         <?php echo csrf_field(); ?>
                            

                                         <div class="row justify-content-center">
                                            <div class="col-md-9">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="x_panel">
                                                    <div class="x_content">
                                                        <div class="card shadow mb-4">
                                                                    <div class="card-header py-3">
                                                                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($link->tajuk_geran); ?></h6>
                                                                    </div>
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-md-8 col-sm-8 col-xs-8 form-group">
                                                                    <?php if( $link->tajuk_geran == 'Hakmilik Sementara Mukim'): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. H.S.M')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_hakmilik); ?> </label><br>
                                                                    <?php elseif( $link->tajuk_geran == 'Hakmilik Sementara Daerah'): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. H.S.D')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_hakmilik); ?> </label><br>
                                                                    <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Hakmilik')); ?>  </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_hakmilik); ?> </label><br>
                                                                    <?php endif; ?>
                                
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Negeri')); ?> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->negeri); ?> </label><br>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Daerah')); ?> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->daerah); ?> </label><br>
                                                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Bandar/Pekan/Mukim')); ?> </label> </label> :   <label class="control-label col-sm-6 " for="first-name"><?php echo e($link->tempat); ?> </label><br>
                                                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Tempat')); ?></label>  </label> :   <label class="control-label col-sm-6" for="first-name"><?php echo e($link->tempat); ?> </label><br>
                                
                                                                 
                                                                        
                                                                     
                                                                    <?php if( $link->tajuk_geran == 'Hakmilik Sementara Daerah' ||$link->tajuk_geran == 'Hakmilik Sementara Mukim'): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. PT')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_pt); ?> </label><br>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Luas Sementara')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->luas_lot); ?> </label><br>
                                                                    <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Lot')); ?></label>   </label> :<label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_lot); ?> </label><br>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Luas Lot')); ?></label>   </label> :<label class="control-label col-sm-6" for="first-name"><?php echo e($link->luas_lot); ?> </label><br>
                                                                    <?php endif; ?>
                                
                                
                                
                                                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Kategori Kegunaan Tanah')); ?></label>  </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->kategori_tanah); ?> </label><br>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Lembaran Piawai')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_lembaran); ?> </label><br>
                                
                                
                                
                                                                    <?php if( $link->tajuk_geran == 'Hakmilik Sementara Daerah' || $link->tajuk_geran == 'Hakmilik Sementara Mukim'): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Permohonan Ukur')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_permohonan); ?> </label><br>
                                                                    <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Pelan Diperakui')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_pelan); ?> </label><br>
                                                                    <?php endif; ?>
                                
                                                                    
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Fail')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->no_fail); ?> </label><br>
                                                                        <br>
                                
                                                                    <?php if($link->rizab == 1): ?>
                                                                    <div class="card bg- text-black shadow " style="width: 150%;">
                                                                        <div class="card-body">
                                                                            Tanah Rizab Melayu 
                                                                            <br> No. Pemberitahuan Warta :    
                                                                            <br> Bertarikh :
                                                                        </div>
                                                                    </div>
                                                                    <?php endif; ?>
                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div class="card shadow mb-4">
                                                                <div class="card-header py-3">
                                                                <h6 class="m-0 font-weight-bold text-primary">Tarikh</h6>
                                                                </div>
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-md-8 col-sm-8 col-xs-8 form-group">
                                                                        <?php if( $link->tajuk_geran == 'Hakmilik Sementara Mukim' || $link->tajuk_geran == 'Hakmilik Sementara Daerah'): ?>
                                                                            
                                                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Tempoh Penyerahan Geran')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->tempoh); ?> </label><br>
                                                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Didaftarkan pada')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->tarikh_daftar); ?> </label><br>
                                                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Dokumen Hakmilik Dikeluarkan')); ?>  </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->tarikh_keluaran); ?> </label><br>
                                                                        <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Didaftarkan pada')); ?></label>   </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->tarikh_daftar); ?> </label><br>
                                                                        <?php endif; ?>
                                
                                                                           
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                
                                                        <div class="card shadow mb-4">
                                                            <div class="card-header py-3">
                                                            <h6 class="m-0 font-weight-bold text-primary">Syarat-Syarat Khas Mengenai <?php echo e($link->tajuk_geran); ?></h6>
                                                            </div>
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-md-8 col-sm-8 col-xs-8 form-group">
                                                                    <?php if( $link->syarat == '' ): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Syarat-Syarat Nyata')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name">Tiada </label><br>
                                                                        <?php if( $link->syarat_kepentingan == ''): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name">Tiada </label><br>
                                                                        <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->syarat_kepentingan); ?> </label><br>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Syarat-Syarat Nyata')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->syarat); ?> </label><br>
                                                                        <?php if( $link->syarat_kepentingan == ''): ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name">Tiada </label><br>
                                                                        <?php else: ?>
                                                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Sekatan-Sekatan Kepentingan')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($link->syarat_kepentingan); ?> </label><br>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                
                                                                       
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                
                                                    <div class="card shadow mb-4">
                                                        <div class="card-header py-3">
                                                        <h6 class="m-0 font-weight-bold text-primary">Gambar Pelan <?php echo e($link->tajuk_geran); ?></h6>
                                                        </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-8 col-sm-8 col-xs-8 form-group">
                                                                <div class="row justify-content-center">
                                                                    
                                                                    <div class="col-md-9">
                                                                        
                                                                    <img src ="<?php echo e(asset('storage/'. $link->gambar_lot)); ?>" alt="" class="img-thumbnail">
                                                                    
                                                                    </div>
                                                                </div>
                                                                   
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            </div>
                               

                            
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                        <a class="btn btn-danger" href="<?php echo url('/lokasi/senarai'); ?>"><?php echo e(trans('Skip')); ?></a>
                                        <button type="submit" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Confirm')); ?></button>
                                    </div>
                                </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
				</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views//lokasi/linklocation.blade.php ENDPATH**/ ?>
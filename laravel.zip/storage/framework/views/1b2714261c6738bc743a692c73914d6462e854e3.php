<?php $__env->startSection('title'); ?>
Tambah Pengguna
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">

			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >

					<div class="card mb-4 py-3 border-bottom-secondry">
						

						<nav class="tab-link" style="margin-left: 8px;" >
					
							<a href="<?php echo url('/user/profile'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Profile Pengguna</b> </a>
							<a href="<?php echo url('/user/setting'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tetapan Maklumat</b></a>
                            
						</nav>
					
					
				</div>
                
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-9">
                                <div class="card" style="margin:50px 0px 0px -50px; ">
                                    
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Pengguna</h6>
                                        </div>
                                    <div class="card-body">
                                        
                                            
                                        <form method="POST" action="update1/<?php echo e($user->id); ?>">
                                            <?php echo csrf_field(); ?>
                    
                                            <div class="form-group row">
                                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>
                    
                                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Telefon')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="phone" type="text" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" value="<?php echo e($user->phone); ?>" placeholder="<?php echo e($user->phone); ?>" required autocomplete="phone" autofocus>
                    
                                                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                    
                                            <div class="form-group row">
                                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($user->email); ?>" placeholder="<?php echo e($user->email); ?>" required autocomplete="email">
                    
                                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alamat')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="address" type="text" class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" value="<?php echo e($user->address); ?>" placeholder="<?php echo e($user->address); ?>" required autocomplete="address" autofocus>
                    
                                                    <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="department" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jabatan')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="department" type="text" class="form-control <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="department" value="<?php echo e($user->department); ?>" placeholder="<?php echo e($user->department); ?>" required autocomplete="name" autofocus>
                    
                                                    <?php if ($errors->has('department')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('department'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <?php if($user->role == 'admin'): ?>
                                            <div class="form-group row">
                                                <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Peranan')); ?></label>
                    
                                                <div class="col-md-6">
                                                    
                                                    <select name="role" id="role" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="<?php echo e($user->role); ?>" required autocomplete="role" autofocus>
                                                        <option value="admin" <?php if($user->role == 'admin'){ echo "selected"; }?>>Admin</option>
                                                        
                                                      </select>
                                                    <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <?php else: ?>
                                            <div class="form-group row">
                                                <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Peranan')); ?></label>
                    
                                                <div class="col-md-6">
                                                    
                                                    <select disabled name="role" id="role" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="<?php echo e($user->role); ?>" required autocomplete="role" autofocus>
                                                        
                                                        <option value="staff" <?php if($user->role == 'staff'){ echo "selected"; }?>>Staff</option>
                                                      </select>
                                                    <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            
                                            
                                            <div class="form-group row">
                                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kata Laluan')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                    
                                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                    
                                            <div class="form-group row">
                                                <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pengesahan Kata Laluan')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                                </div>
                                            </div>

                    

                    
                                            <div class="form-group row mb-0">
                                                <div class="col-md-6 offset-md-4">
                                                    <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Batal')); ?></a>
                                                    <button type="submit" class="btn btn-primary">
                                                        <?php echo e(__('Kemaskini')); ?>

                                                    </button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/user/setting.blade.php ENDPATH**/ ?>
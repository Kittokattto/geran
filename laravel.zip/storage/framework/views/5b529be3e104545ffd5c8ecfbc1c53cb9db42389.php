<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
            <!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Pengurusan Geran Tanah</title>

         <!-- Bootstrap CSS CDN -->
         
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
        
       
        <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
        <!-- Full Calender -->

        
        


          
          
          

        
        <!-- Our Custom CSS -->
        
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/fl-table.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/user-list.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/sb-admin-2.min.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('scss/tab.scss')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/task.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/profile.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/table.css')); ?>">
        


        <!-- Fonts -->
        
         <link rel="stylesheet" href=" <?php echo e(URL::asset('vendor/fontawesome-free/css/all.min.css')); ?>" >
        
        <link rel="stylesheet" href=" <?php echo e(URL::asset('css/fontawesome.min.css')); ?>">
        
        <!-- Sweet Alert -->

    </head>
    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper" >

            <!-- Sidebar -->
            <div  id="sidebar">
                <div class="sticky-top">
            <ul  class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">
    
                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo url('/home'); ?>">
                    <div class="sidebar-brand-icon rotate-n-15">
                      
                    </div>
                    <div class="sidebar-brand-text mx-3"><h4>Portal</h4> <h6>Pengurusan Fail</h6></div>
                </a>
    
                <!-- Divider -->
                <hr class="sidebar-divider my-0">
    
                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo url('/home'); ?>">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span>Dashboard</span></a>
                </li>
    
                
    
                
    
                <!-- Divider -->
                <hr class="sidebar-divider">
    
                <!-- Heading -->
                <div class="sidebar-heading">
                    Kegunaan
                </div>
    
                <!-- Nav Item - Pengguna -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePengguna"
                        aria-expanded="true" aria-controls="collapsePages">
                        <i class="fas fa-fw fa-user-circle"></i>
                        <span>Pengguna</span>
                    </a>
                    <div id="collapsePengguna" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <h6 class="collapse-header">Pengguna:</h6>
                            <a class="collapse-item" href="<?php echo url('/pengguna/senarai'); ?>">Senarai Pengguna</a>
                            <a class="collapse-item" href="<?php echo url('/pengguna/tambah'); ?>">Tambah Pengguna</a>

                            <div class="collapse-divider"></div>
                            <h6 class="collapse-header">Pengguna yang dipadam:</h6>
                            <a class="collapse-item" href="<?php echo url('/pengguna/senaraipadam'); ?>">Senarai yang dipadamkan</a>
                        </div>
                    </div>
                </li>

                    <!-- Nav Item - Geran -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseGeran"
                        aria-expanded="true" aria-controls="collapsePages">
                        <i class="fas fa-fw fa-folder"></i>
                        <span>Geran</span>
                    </a>
                    <div id="collapseGeran" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <h6 class="collapse-header">Geran:</h6>
                            <a class="collapse-item" href="<?php echo url('/failkes/senarai'); ?>">Senarai Geran</a>
                            <a class="collapse-item" href="<?php echo url('/failkes/tambah'); ?>">Tambah Geran</a>
                            <div class="collapse-divider"></div>
                            <h6 class="collapse-header">Geran yang Dipadam:</h6>
                            <a class="collapse-item" href="<?php echo url('/failkes/senaraipadam'); ?>">Senarai yang dipadamkan</a>
                        </div>
                    </div>
                </li>

                <!-- Nav Item - Lokasi -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLokasi"
                        aria-expanded="true" aria-controls="collapsePages">
                        <i class="fas fa-fw fa-podcast"></i>
                        <span>Lokasi</span>
                    </a>
                    <div id="collapseLokasi" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <h6 class="collapse-header">Lokasi:</h6>
                            <a class="collapse-item" href="<?php echo url('/lokasi/senarai'); ?>">Senarai Lokasi Failkes</a>
                            <a class="collapse-item" href="<?php echo url('/lokasi/tambah'); ?>">Tambah Lokasi Failkes</a>

                            <div class="collapse-divider"></div>
                            <h6 class="collapse-header">Pengguna yang dipadamkan:</h6>
                            <a class="collapse-item" href="<?php echo url('/lokasi/senaraipadam'); ?>">Senarai yang dipadamkan</a>
                        </div>
                    </div>
                </li>
                <!-- Nav Item - Access -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo url('/tugas/senarai'); ?>">
                        <i class="fas fa-fw fa-paperclip"></i>
                        <span>Pembahagian Tugas</span></a>
                </li>
                <!-- Nav Item - Access -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo url('/user/profile'); ?>">
                        <i class="fas fa-fw fa-cog"></i>
                        <span>Tetapan</span></a>
                </li>
                <!-- Nav Item - Charts -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo url('/access/senarai'); ?>">
                        <i class="fas fa-fw fa-table"></i>
                        <span>Akses</span></a>
                </li>
    
                
    
                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">
    
                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="rounded-circle border-0" id="sidebarToggle"></button>
                </div>
    
                <!-- Sidebar Message -->
                <div class="sidebar-card">
                    
                </div>
    
            </ul>

                </div>
            </div>
            <!-- End of Sidebar -->
    
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
    
                <!-- Main Content -->
                <div id="content">
    
                    <!-- Topbar -->
                    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    
                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
    
                        <!-- Topbar Search -->
                        
                        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                            <div class="sidebar-brand-icon rotate-n-15">
                                
                            </div>
                            
                            <img style="margin-left: 8px;" src="<?php echo e(URL::asset('/img/ptg2.jpg')); ?>" alt="Image"/>
                        </a>


                        <!-- Topbar Navbar -->
                        <ul class="navbar-nav ml-auto">
    
                            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                            <li class="nav-item dropdown no-arrow d-sm-none">
                                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-search fa-fw"></i>
                                </a>
                                <!-- Dropdown - Messages -->
                                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                    aria-labelledby="searchDropdown">
                                    <form class="form-inline mr-auto w-100 navbar-search">
                                        <div class="input-group">
                                            <input type="text" class="form-control bg-light border-0 small"
                                                placeholder="Search for..." aria-label="Search"
                                                aria-describedby="basic-addon2">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="button">
                                                    <i class="fas fa-search fa-sm"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </li>
    
                            <!-- Nav Item - Alerts -->
                            
                            <!-- Nav Item - Messages -->
                            
                            <div class="topbar-divider d-none d-sm-block"></div>
    
                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" id="userDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?> <span class="caret"></span></span>
                                    
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                    aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="<?php echo url('/user/profile'); ?>">
                                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Profile
                                    </a>
                                    <a class="dropdown-item" href="<?php echo url('/user/setting/'.Auth::user()->id ); ?>">
                                        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Tetapan
                                    </a>
                                    <a class="dropdown-item" href="<?php echo url('/tugas/senarai'); ?>">
                                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Tugasan
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"data-toggle="modal" data-target="#logoutModal" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                        
                                        
                                         <?php echo e(__('Logout')); ?>

                                        
 
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                         <?php echo csrf_field(); ?>
                                        </form>
                                        
                                    </a>
                                </div>
                            </li>
                            
                        </ul>
    
                    </nav>
                    <!-- End of Topbar -->
                    
                    <div class="container-fluid">
                        

                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
                                <?php echo $__env->yieldContent('search'); ?>
                        </div>


                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                    
                </div>
                <!-- End of Main Content -->
    
                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Pengurusan Geran Tanah &copy; Johor</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->
    
            </div>
            <!-- End of Content Wrapper -->
    
        </div>
        <!-- End of Page Wrapper -->
    
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
    
        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>






             <!-- Bootstrap core JavaScript-->
             <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
            
            <script src="<?php echo e(URL::asset('vendor/jquery/jquery.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

            <!-- Core plugin JavaScript-->
            <script src="<?php echo e(URL::asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
            <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
            <!-- Custom scripts for all pages-->
            <script src="<?php echo e(URL::asset('js/sb-admin-2.min.js')); ?>"></script>

            <!-- Page level plugins -->
            

            <!-- Page level custom scripts -->
            

            <!-- Full Calendar -->

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\geran\resources\views/layouts/main.blade.php ENDPATH**/ ?>
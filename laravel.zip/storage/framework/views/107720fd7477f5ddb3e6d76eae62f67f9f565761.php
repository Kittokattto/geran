<?php $__env->startSection('title'); ?>
Fail Kes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<style>
    .theTooltip {
            position: absolute!important;
    -webkit-transform-style: preserve-3d; transform-style: preserve-3d; -webkit-transform: translate(15%, -50%); transform: translate(15%, -50%);
    }
    </style>


<!-- page content -->
<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        


                    <div class="card mb-4 py-3 border-bottom-secondry">
                        <nav class="tab-link" style="margin-left: 8px;" >
                    
                            <a href="<?php echo url('/lokasi/senarai'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b> Senarai Lokasi Fail Kes</b> </a>
                            <a href="<?php echo url('/lokasi/tambah'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b> Tambah Lokasi fail kes</b></a>
                            <a href="<?php echo url('/lokasi/view/'.$lokasi->id); ?>" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b> Lokasi fail kes</b></a>
                        </nav>                    
                    </div>
                    
            <div class="row justify-content-center">
            <div class="col-md-9">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Maklumat Lokasi Fail</h6>
                                    </div>
                        <div class="card-body">
                        <div class="row">
                                <div class="col-md-8 col-sm-8 col-xs-8 form-group">
                                    
                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Tajuk Fail')); ?> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->tajuk_file); ?> </label><br>
                                        <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Jenis Fail')); ?> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->jenis_file); ?> </label><br>
                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Kod Fail')); ?>  </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->kod); ?> </label><br>
                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Status Fail')); ?></label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->status); ?> </label><br>
                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Jumlah Salinan')); ?></label> : <label class="control-label col-sm-6 " for="first-name"><?php echo e($lokasi->copy); ?> </label><br>
                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Tarikh Disimpan')); ?></label> : <label class="control-label col-sm-6 " for="first-name"><?php echo e($lokasi->date_locate); ?> </label><br>
                                        <label class="control-label col-md-5" for="first-name"><?php echo e(trans('Lokasi')); ?> </label> : <label class="control-label col-sm-3 " for="first-name">
                                            
                                        
                                            <div class="card-body bg-primary text-white shadow">

                                               <div class="row justify-content-center"><?php echo e($lokasi->lokasi); ?>

                                            </div>
                                            </div>
                                        
                                        </label><br>    


                                </div>
                            </div>
                        </div>
                        </div>
 
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Maklumat Ringkas Fail</h6>
                                </div>
                            <div class="card-body">
                                <div class="row">
                                    
                                    <div class="col-md-8 col-sm-8 col-xs-8 form-group">

                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Nama Pemilik')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->pemilik); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('No. Hakmilik Fail')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->no_hakmilik); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Negeri')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->negeri); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Daerah')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->daerah); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Lot Tanah')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->no_lot); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Tempat/Alamat')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->tempat); ?> </label><br>
                                            <label class="control-label col-sm-5" for="first-name"><?php echo e(trans('Info Fail')); ?> </label> </label> : <label class="control-label col-sm-6" for="first-name"><?php echo e($lokasi->info); ?> </label><br>

                                        
                                    </div>
                                           
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
            </div>
            </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/lokasi/view.blade.php ENDPATH**/ ?>
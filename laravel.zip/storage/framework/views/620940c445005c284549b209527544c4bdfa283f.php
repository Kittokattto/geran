<?php $__env->startSection('title'); ?>
Tambah Pengguna
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





<!-- page content -->
	<div class="right_col" role="main">
        <div id="myModal" class="modal fade" role="dialog">
			<div class="modal-dialog modal-lg">
    <!-- Modal content-->
				<div class="modal-content modal_data">
				</div>
			</div>
        </div>
		
		<!-- Modal for Coupon Data -->
			<div class="modal fade" id="coupaon_data" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content used_coupn_modal_data">
						
					</div>
				</div>
			</div>
		<!-- End Modal for Coupon Data -->
        <div class="">

			<div class="row" >
				<div class="col-md-12 col-sm-12 col-xs-12" >

					<div class="card mb-4 py-3 border-bottom-secondry">
						

						<nav class="tab-link" style="margin-left: 8px;" >
					
							<a href="<?php echo url('/user/profile'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Profile Pengguna</b> </a>
							<a href="<?php echo url('/user/setting'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><span class="visible-xs"></span><i class="fa">&nbsp;</i><b>Tetapan Kata Laluan</b></a>
                            <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-outline-primary shadow-sm"> <span class="visible-xs"></span><i class="fa"></i><b>Kemaskini Profile Pengguna</b> </a>
						</nav>
					
					
				</div>
                
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-9">
                                <div class="card" style="margin:50px 0px 0px -50px; ">
                                    
                                    <div class="card shadow mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Sosial Media</h6>
                                        </div>
                                    <div class="card-body">
                                        
                                            
                                        <form method="POST" action="update/<?php echo e($socmed->id); ?>" class="form-horizontal upperform">
                                            <?php echo csrf_field(); ?>
                    
                                            <div class="form-group row">
                                                <label for="linked" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Linked In')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="linked" value="<?php echo e($socmed->linked); ?>" placeholder="<?php echo e($socmed->linked); ?>" type="text" class="form-control <?php if ($errors->has('linked')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('linked'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="linked" value="<?php echo e(old('linked')); ?>"  autocomplete="linked" autofocus>
                    
                                                    <?php if ($errors->has('linked')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('linked'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="github" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Git Hub')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="github" value="<?php echo e($socmed->github); ?>" placeholder="<?php echo e($socmed->github); ?>" type="text" class="form-control <?php if ($errors->has('github')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('github'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="github" value="<?php echo e(old('github')); ?>"  autocomplete="github" autofocus>
                    
                                                    <?php if ($errors->has('github')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('github'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                    
                                            <div class="form-group row">
                                                <label for="insta" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Instagram')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="insta" value="<?php echo e($socmed->inst); ?>" placeholder="<?php echo e($socmed->inst); ?>" type="text" class="form-control <?php if ($errors->has('insta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('insta'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="insta" value="<?php echo e(old('insta')); ?>"  autocomplete="insta">
                    
                                                    <?php if ($errors->has('insta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('insta'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="twitter" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Twitter')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="twitter" value="<?php echo e($socmed->twitter); ?>" placeholder="<?php echo e($socmed->twitter); ?>" type="text" class="form-control <?php if ($errors->has('twitter')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('twitter'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="twitter" value="<?php echo e(old('twitter')); ?>"  autocomplete="twitter" autofocus>
                    
                                                    <?php if ($errors->has('twitter')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('twitter'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="facebook" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Facebook')); ?></label>
                    
                                                <div class="col-md-6">
                                                    <input id="facebook" value="<?php echo e($socmed->facebook); ?>" placeholder="<?php echo e($socmed->facebook); ?>" type="text" class="form-control <?php if ($errors->has('facebook')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="facebook" value="<?php echo e(old('facebook')); ?>"  autocomplete="facebook" autofocus>
                    
                                                    <?php if ($errors->has('facebook')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>

                    
                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                                                    <a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('Batal')); ?></a>
                                                    <button type="submit" class="btn btn-success customerAddSubmitButton"><?php echo e(trans('Mengemaskini')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\geran\resources\views/user/edit.blade.php ENDPATH**/ ?>
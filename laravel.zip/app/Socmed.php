<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Socmed extends Model
{
    //
    protected $table = 'socmed';
}
